 # using stramlit

import streamlit as st
from utils.image_utils import save_uploaded_image, preprocess_image
from utils.vision_model import detect_rooftop_area
from utils.panel_fitment import calculate_panel_fitment
from utils.roi_estimator import estimate_roi
from utils.recommendations import get_recommendations
import json

st.title("Solar Rooftop AI Assistant")

uploaded_file = st.file_uploader("Upload rooftop image (satellite view)", type=["jpg", "png", "jpeg"])

if uploaded_file:
    filepath = save_uploaded_image(uploaded_file)
    image = preprocess_image(filepath)
    st.image(image, caption="Preprocessed Image", use_column_width=True)

    with st.spinner("Analyzing rooftop..."):
        response = detect_rooftop_area(image)
        st.success("Analysis complete!")
        st.code(response, language="json")

        try:
            result = json.loads(response)
            panels = calculate_panel_fitment(result.get("usable_roof_area", 0))
            roi = estimate_roi(panels)
            tips = get_recommendations()

            st.subheader("Rooftop Analysis")
            st.write(f"Usable Area: {result['usable_roof_area']} m²")
            st.write(f"Estimated Panels: {panels}")
            st.write(f"Annual Generation: {result['annual_generation_kWh']} kWh")

            st.subheader("ROI Estimation")
            st.write(roi)

            st.subheader("Recommendations")
            st.write(tips)

        except Exception as e:
            st.error(f"Failed to parse AI response: {e}")
