# Regulation and Maintenance
def get_recommendations():
    return {
        "maintenance": "Clean panels every 3-6 months. Monitor inverter.",
        "permits": "Check with local DISCOM for net metering. Submit rooftop plan.",
        "warranty": "Most panels have 25-year performance warranty."
    }
