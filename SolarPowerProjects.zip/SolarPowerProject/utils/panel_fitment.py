# Fitment logic
def calculate_panel_fitment(area_m2, panel_size_m2=1.7):
    if area_m2 <= 0:
        return 0
    return int(area_m2 / panel_size_m2)
