# ROI & Cost Calculation

def estimate_roi(num_panels, cost_per_panel=10000, annual_savings_per_panel=4000):
    total_cost = num_panels * cost_per_panel
    annual_savings = num_panels * annual_savings_per_panel
    payback_years = total_cost / annual_savings if annual_savings else 0
    return {
        "Total cost": total_cost,
        "Annual savings": annual_savings,
        "Payback period years": round(payback_years, 2)
    }
