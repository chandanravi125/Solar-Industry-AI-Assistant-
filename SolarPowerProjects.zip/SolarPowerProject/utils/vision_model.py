# Rooftop Detextion
import openai
from PIL import Image
import base64
import io

# Set your key: openai.api_key = "your-key"


OPENAI_API_KEY= "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"

def encode_image(image):
    buffered = io.BytesIO()
    image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")

def detect_rooftop_area(image: Image.Image):
    encoded = encode_image(image)
    prompt = """
You are a solar AI assistant. Analyze this rooftop image and estimate:
1. Usable rooftop area (in sq.m)
2. Number of standard 1.7m x 1m panels
3. Annual solar energy generation (kWh)
Return JSON format only.
"""
    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[
            {"role": "user", "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{encoded}"}}
            ]}
        ]
    )
    return response['choices'][0]['message']['content']

